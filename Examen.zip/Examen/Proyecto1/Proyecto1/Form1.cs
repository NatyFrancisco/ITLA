﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void rangoConCicloForToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form cicloFor = new For();
            cicloFor.Show();

        }

        private void rangoConWhileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form cicloWhile = new While();
            cicloWhile.Show();
        }

        private void rangoConDoWhileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form cicloDoWhile = new doWhile();
            cicloDoWhile.Show();
        }

        private void cantidadDeDigitosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form cantidadDigitos = new Digitos();
            cantidadDigitos.Show();
        }

        private void notasDeAlumnosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form notasAlumnos = new Notas();
            notasAlumnos.Show();
        }

        private void tarjetaDeVacunacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form tarjVacuna = new Vacuna();
            tarjVacuna.Show();
        }
    }
}
