﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto1
{
    public partial class Notas : Form
    {
        public Notas()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnvalidar_Click(object sender, EventArgs e)
        {
            string[] notasAlumnos = nota1.Text.Split(' ');
            int[] notas = new int[8];
            int notaMayorOIgual = 0;
            int notasMenores = 0;

            if (notasAlumnos.Length != 8)
            {
                MessageBox.Show("Ingrese solamente 8 notas por separadas y sin espacios.");
                return;
            }

            for (int i = 0; i < 8; i++)
            {
                if (int.TryParse(notasAlumnos[i], out notas[i]))
                {
                    if (notas[i] >= 13)
                    {
                        notaMayorOIgual++;
                    }
                    else
                    {
                        notasMenores++;
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, las notas deben válidas. Digite las notas nuevamente.");
                    return;
                }
            }

                   MessageBox.Show("Las notas son mayores o iguales a 13 son " + notaMayorOIgual + " y las notas menores a 13 son " + notasMenores);
        }

        private void btnborrar_Click(object sender, EventArgs e)
        {
            nota1.Text = "";
        }
    }
}
