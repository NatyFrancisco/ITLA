﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto1
{
    public partial class Digitos : Form
    {
        public Digitos()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            int num = int.Parse(txtnum.Text);
            int contador = 0;

            if (num < 1)
            {
                MessageBox.Show("No se permiten numeros negativos. Por favor ingrese un numero positivo entero");
            }

            while (num >= 1)
            {
                contador = contador + 1;
                num = num / 10;
            }

             txtresultado.Text = ("El numero tiene " + contador + " digitos.");


           

        }

        private void btnborrar_Click(object sender, EventArgs e)
        {
            txtnum.Text = "";
            txtresultado.Text = "";
        }
    }
}
