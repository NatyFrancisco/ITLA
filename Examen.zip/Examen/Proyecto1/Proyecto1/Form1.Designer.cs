﻿
namespace Proyecto1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.rangoDeDosNumeroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rangoConCicloForToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rangoConWhileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rangoConDoWhileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cantidadDeDigitosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notasDeAlumnosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tarjetaDeVacunacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rangoDeDosNumeroToolStripMenuItem,
            this.cantidadDeDigitosToolStripMenuItem,
            this.notasDeAlumnosToolStripMenuItem,
            this.tarjetaDeVacunacionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1067, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // rangoDeDosNumeroToolStripMenuItem
            // 
            this.rangoDeDosNumeroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rangoConCicloForToolStripMenuItem,
            this.rangoConWhileToolStripMenuItem,
            this.rangoConDoWhileToolStripMenuItem});
            this.rangoDeDosNumeroToolStripMenuItem.Name = "rangoDeDosNumeroToolStripMenuItem";
            this.rangoDeDosNumeroToolStripMenuItem.Size = new System.Drawing.Size(136, 20);
            this.rangoDeDosNumeroToolStripMenuItem.Text = "Rango de dos numero";
            // 
            // rangoConCicloForToolStripMenuItem
            // 
            this.rangoConCicloForToolStripMenuItem.Name = "rangoConCicloForToolStripMenuItem";
            this.rangoConCicloForToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.rangoConCicloForToolStripMenuItem.Text = "Rango con Ciclo For";
            this.rangoConCicloForToolStripMenuItem.Click += new System.EventHandler(this.rangoConCicloForToolStripMenuItem_Click);
            // 
            // rangoConWhileToolStripMenuItem
            // 
            this.rangoConWhileToolStripMenuItem.Name = "rangoConWhileToolStripMenuItem";
            this.rangoConWhileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.rangoConWhileToolStripMenuItem.Text = "Rango con While";
            this.rangoConWhileToolStripMenuItem.Click += new System.EventHandler(this.rangoConWhileToolStripMenuItem_Click);
            // 
            // rangoConDoWhileToolStripMenuItem
            // 
            this.rangoConDoWhileToolStripMenuItem.Name = "rangoConDoWhileToolStripMenuItem";
            this.rangoConDoWhileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.rangoConDoWhileToolStripMenuItem.Text = "Rango con Do While";
            this.rangoConDoWhileToolStripMenuItem.Click += new System.EventHandler(this.rangoConDoWhileToolStripMenuItem_Click);
            // 
            // cantidadDeDigitosToolStripMenuItem
            // 
            this.cantidadDeDigitosToolStripMenuItem.Name = "cantidadDeDigitosToolStripMenuItem";
            this.cantidadDeDigitosToolStripMenuItem.Size = new System.Drawing.Size(122, 20);
            this.cantidadDeDigitosToolStripMenuItem.Text = "Cantidad de digitos";
            this.cantidadDeDigitosToolStripMenuItem.Click += new System.EventHandler(this.cantidadDeDigitosToolStripMenuItem_Click);
            // 
            // notasDeAlumnosToolStripMenuItem
            // 
            this.notasDeAlumnosToolStripMenuItem.Name = "notasDeAlumnosToolStripMenuItem";
            this.notasDeAlumnosToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.notasDeAlumnosToolStripMenuItem.Text = "Notas de alumnos";
            this.notasDeAlumnosToolStripMenuItem.Click += new System.EventHandler(this.notasDeAlumnosToolStripMenuItem_Click);
            // 
            // tarjetaDeVacunacionToolStripMenuItem
            // 
            this.tarjetaDeVacunacionToolStripMenuItem.Name = "tarjetaDeVacunacionToolStripMenuItem";
            this.tarjetaDeVacunacionToolStripMenuItem.Size = new System.Drawing.Size(133, 20);
            this.tarjetaDeVacunacionToolStripMenuItem.Text = "Tarjeta de vacunacion";
            this.tarjetaDeVacunacionToolStripMenuItem.Click += new System.EventHandler(this.tarjetaDeVacunacionToolStripMenuItem_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(823, 49);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Proyecto1.Properties.Resources.logo_fondo_blanco_preview_1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(245, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(520, 294);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "INICIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rangoDeDosNumeroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rangoConCicloForToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rangoConWhileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rangoConDoWhileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cantidadDeDigitosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notasDeAlumnosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tarjetaDeVacunacionToolStripMenuItem;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

