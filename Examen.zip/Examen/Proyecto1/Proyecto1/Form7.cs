﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto1
{
    public partial class Vacuna : Form
    {
        string[] nombres = new string[20];
        string[] edad = new string[8];
        string[] nombres = new string[8];
        string[] nombres = new string[8];
        string[] nombres = new string[8];
        string[] nombres = new string[8];
        string[] nombres = new string[8];
        string[] nombres = new string[8];

        public Vacuna()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            strings[0] = "String 1";
            strings[1] = "String 2";
            strings[2] = "String 3";
            strings[3] = "String 4";
            strings[4] = "String 5";
            strings[5] = "String 6";
            strings[6] = "String 7";
            strings[7] = "String 8";
        }
    }
}
