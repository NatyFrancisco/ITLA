﻿
namespace Proyecto1
{
    partial class Notas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nota1 = new System.Windows.Forms.TextBox();
            this.btnvalidar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.btnborrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese 8 notas de los alumnos por separado";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // nota1
            // 
            this.nota1.Location = new System.Drawing.Point(50, 219);
            this.nota1.Name = "nota1";
            this.nota1.Size = new System.Drawing.Size(359, 22);
            this.nota1.TabIndex = 2;
            // 
            // btnvalidar
            // 
            this.btnvalidar.BackColor = System.Drawing.Color.PowderBlue;
            this.btnvalidar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvalidar.Location = new System.Drawing.Point(50, 284);
            this.btnvalidar.Name = "btnvalidar";
            this.btnvalidar.Size = new System.Drawing.Size(161, 48);
            this.btnvalidar.TabIndex = 24;
            this.btnvalidar.Text = "Validar notas";
            this.btnvalidar.UseVisualStyleBackColor = false;
            this.btnvalidar.Click += new System.EventHandler(this.btnvalidar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkCyan;
            this.label9.Location = new System.Drawing.Point(50, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(380, 25);
            this.label9.TabIndex = 27;
            this.label9.Text = "Programa de notas para 8 alumnos";
            // 
            // btnborrar
            // 
            this.btnborrar.BackColor = System.Drawing.Color.PowderBlue;
            this.btnborrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrar.Location = new System.Drawing.Point(248, 284);
            this.btnborrar.Name = "btnborrar";
            this.btnborrar.Size = new System.Drawing.Size(161, 48);
            this.btnborrar.TabIndex = 28;
            this.btnborrar.Text = "Borrar";
            this.btnborrar.UseVisualStyleBackColor = false;
            this.btnborrar.Click += new System.EventHandler(this.btnborrar_Click);
            // 
            // Notas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1198, 590);
            this.Controls.Add(this.btnborrar);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnvalidar);
            this.Controls.Add(this.nota1);
            this.Controls.Add(this.label1);
            this.Name = "Notas";
            this.Text = "Notas para alumnos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nota1;
        private System.Windows.Forms.Button btnvalidar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnborrar;
    }
}